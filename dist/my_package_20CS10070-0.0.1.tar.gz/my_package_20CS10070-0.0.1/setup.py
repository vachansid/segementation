import setuptools


setuptools.setup(
    name="my_package_20CS10070",
    version="0.0.1",
    author="Vachan Siddharth",
    author_email="author@example.com",
    description="Package for Software Engineering Lab Assignment",
    packages=setuptools.find_packages(),
    python_requires='>=3.6',
)
